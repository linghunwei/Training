package com.starbooks.helper;

public class HibernateUtil 
{
    
}
