package com.starbooks.model;

import java.util.*;

public class ReaderHibernateDAO implements ReaderDAO
{
    public int delete(String readerId)
    {
        int updateCount = 0;

        

        return updateCount;
    }

    public Collection<Reader> findAll()
    {
        List<Reader> readerList = null;

        

        return readerList;
    }

    public Reader findByPrimaryKey(String readerId)
    {
        Reader reader = null;

        

        return reader;
    }

    public int insert(Reader reader)
    {
        int updateCount = 0;


        
        return updateCount;
    }

    public int update(Reader reader)
    {
        int updateCount = 0;


        
        return updateCount;
    }
}
