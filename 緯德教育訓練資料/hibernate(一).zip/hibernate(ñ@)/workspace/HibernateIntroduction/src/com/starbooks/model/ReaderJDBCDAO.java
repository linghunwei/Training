package com.starbooks.model;

import java.sql.*;
import java.util.*;


public class ReaderJDBCDAO implements ReaderDAO
{
    final static String INSERT = "insert into reader values (?, ?, ?, ?, ?, ?)";
    final static String DELETE = "delete from reader where readerID = ?";
    final static String FIND = "select * from reader where readerID = ?";
    final static String UPDATE = 
        "update reader " +
        "set name = ?, birthday = ?, married = ?, maxAllowed = ?, email = ? " +
        "where readerID = ?";
    final static String FIND_ALL = "select * from reader";
    
    public int insert(Reader reader)
    {
        int updateCount = 0;
        
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try
        {
            conn = DatabaseUtils.getConnection();                      
            stmt = conn.prepareStatement(INSERT);
            
            stmt.setString(1, reader.getName());
            stmt.setString(2, reader.getReaderId());
            stmt.setDate(3, reader.getBirthday());
            stmt.setBoolean(4, reader.getMarried());
            stmt.setInt(5, reader.getMaxAllowed());
            stmt.setString(6, reader.getEmail());
            
            updateCount = stmt.executeUpdate();     
            
            stmt.close();
            conn.close();
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }    
        finally
        {
            DatabaseUtils.closeStatement(stmt);
            DatabaseUtils.closeConnection(conn);
        }

        return updateCount;        
    }
    
    public int delete(String readerId)
    {
        int updateCount = 0;
        
        Connection conn = null;
        PreparedStatement stmt = null;

        try
        {
            conn = DatabaseUtils.getConnection();                      
            stmt = conn.prepareStatement(DELETE);
            stmt.setString(1, readerId);
            updateCount = stmt.executeUpdate();                 
            stmt.close();
            conn.close();
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }    
        finally
        {
            DatabaseUtils.closeStatement(stmt);
            DatabaseUtils.closeConnection(conn);
        }

        return updateCount;                
    }
    
    public Reader findByPrimaryKey(String readerId)
    {
        Reader reader = new Reader();
        
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try
        {
            conn = DatabaseUtils.getConnection();                      
            stmt = conn.prepareStatement(FIND);
            stmt.setString(1, readerId);
            rs = stmt.executeQuery();
            
            if (rs.next())
            {
                reader.setName(rs.getString("name"));
                reader.setReaderId(rs.getString("readerID"));
                reader.setBirthday(rs.getDate("birthday"));
                reader.setMarried(rs.getBoolean("married"));
                reader.setMaxAllowed(rs.getInt("maxAllowed"));
                reader.setEmail(rs.getString("email"));
            }
         
            rs.close();
            stmt.close();
            conn.close();
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }    
        finally
        {
            DatabaseUtils.closeResultSet(rs);
            DatabaseUtils.closeStatement(stmt);
            DatabaseUtils.closeConnection(conn);
        }

        return reader;                
    }
    
    public int update(Reader reader)
    {
        int updateCount = 0;
        
        Connection conn = null;
        PreparedStatement stmt = null;

        try
        {
            conn = DatabaseUtils.getConnection();                      
            stmt = conn.prepareStatement(UPDATE);
            stmt.setString(1, reader.getName());
            stmt.setDate(2, reader.getBirthday());
            stmt.setBoolean(3, reader.getMarried());
            stmt.setInt(4, reader.getMaxAllowed());
            stmt.setString(5, reader.getEmail());
            stmt.setString(6, reader.getReaderId());
            updateCount = stmt.executeUpdate();                 
            stmt.close();
            conn.close();
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }    
        finally
        {
            DatabaseUtils.closeStatement(stmt);
            DatabaseUtils.closeConnection(conn);
        }

        return updateCount;                
    }
    
    public Collection<Reader> findAll()
    {
        List<Reader> readerList = new ArrayList<Reader>();        

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try
        {
            conn = DatabaseUtils.getConnection();                      
            stmt = conn.prepareStatement(FIND_ALL);
            rs = stmt.executeQuery();     
            while (rs.next())
            {
                Reader reader = new Reader();
                reader.setName(rs.getString("name"));
                reader.setReaderId(rs.getString("readerId"));
                reader.setBirthday(rs.getDate("birthday"));
                reader.setMarried(rs.getBoolean("married"));
                reader.setMaxAllowed(rs.getInt("maxAllowed"));
                reader.setEmail(rs.getString("email"));
                readerList.add(reader);
            }
            
            rs.close();
            stmt.close();
            conn.close();
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }    
        finally
        {
            DatabaseUtils.closeResultSet(rs);
            DatabaseUtils.closeStatement(stmt);
            DatabaseUtils.closeConnection(conn);            
        }

        return readerList;
    }    
}
