package com.starbooks.model;

import java.util.*;

public interface ReaderDAO
{
    public int insert(Reader reader);
    public int delete(String readerId);
    public Reader findByPrimaryKey(String readerId);
    public int update(Reader reader);
    public Collection<Reader> findAll();
}
