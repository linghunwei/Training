package com.starbooks.view;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import com.starbooks.model.*;
import quick.dbtable.*;

public class ReaderManager extends JFrame
{
    static final long serialVersionUID = 2009L;

    private JPanel contentPane = null;

    private JPanel pnlFields = new JPanel();
    private JLabel lblName = new JLabel("Name");
    private JLabel lblReaderID = new JLabel("Reader ID");
    private JLabel lblBirthday = new JLabel("Birthday");
    private JLabel lblMarried = new JLabel("Married");
    private JLabel lblMaxAllowed = new JLabel("Max Allowed");
    private JLabel lblEmail = new JLabel("Email");
    private JTextField txtName = new JTextField("Monster");
    private JTextField txtReaderID = new JTextField("A123456789");
    private JTextField txtBirthday = new JTextField("2001-01-01");
    private ButtonGroup grpMarried = new ButtonGroup();
    private JRadioButton btnYes = new JRadioButton("Yes");
    private JRadioButton btnNo = new JRadioButton("No", true);
    private JPanel pnlMarried = new JPanel();
    private JTextField txtMaxAllowed = new JTextField("10");
    private JTextField txtEmail = new JTextField("monster@iii.org.tw");
    private JButton btnInsert = new JButton("Insert");
    private JButton btnDelete = new JButton("Delete");
    private JButton btnFind = new JButton("Find");
    private JButton btnUpdate = new JButton("Update");
    private JButton btnRefresh = new JButton("Refresh");

    private DBTable tblReaders = new DBTable();
    private JScrollPane pnlGrids = new JScrollPane(tblReaders);

    private JLabel lblStatus = new JLabel(" ");

    private ReaderDAO readerDAO = new ReaderJDBCDAO();

    public ReaderManager()
    {
        grpMarried.add(btnYes);
        grpMarried.add(btnNo);

        pnlMarried.add(btnYes);
        pnlMarried.add(btnNo);

        GridLayout fieldsLayout = new GridLayout(6, 3);
        pnlFields.setLayout(fieldsLayout);

        pnlFields.add(lblName);
        pnlFields.add(txtName);
        pnlFields.add(btnInsert);
        pnlFields.add(lblReaderID);
        pnlFields.add(txtReaderID);
        pnlFields.add(btnDelete);
        pnlFields.add(lblBirthday);
        pnlFields.add(txtBirthday);
        pnlFields.add(btnFind);
        pnlFields.add(lblMarried);
        pnlFields.add(pnlMarried);
        pnlFields.add(btnUpdate);
        pnlFields.add(lblMaxAllowed);
        pnlFields.add(txtMaxAllowed);
        pnlFields.add(new JLabel());
        pnlFields.add(lblEmail);
        pnlFields.add(txtEmail);
        pnlFields.add(btnRefresh);

        btnInsert.addActionListener(new ReaderInsertListener(this));
        btnDelete.addActionListener(new ReaderDeleteListener(this));
        btnFind.addActionListener(new ReaderFindListener(this));
        btnUpdate.addActionListener(new ReaderUpdateListener(this));
        btnRefresh.addActionListener(new ReaderRefreshListener(this));

        contentPane = (JPanel) this.getContentPane();
        contentPane.add(pnlFields, BorderLayout.NORTH);
        contentPane.add(pnlGrids, BorderLayout.CENTER);
        contentPane.add(lblStatus, BorderLayout.SOUTH);

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocation(100, 100);
        this.setSize(800, 600);
        this.setTitle("Reader Manager");
        this.setVisible(true);
    }

    public void insertActionPerformed(ActionEvent e)
    {
        Reader reader = new Reader();
        reader.setName(txtName.getText());
        reader.setReaderId(txtReaderID.getText());
        reader.setBirthday(java.sql.Date.valueOf(txtBirthday.getText()));
        reader.setMarried(btnYes.isSelected());
        reader.setMaxAllowed(Integer.parseInt(txtMaxAllowed.getText()));
        reader.setEmail(txtEmail.getText());
        int updateCount = readerDAO.insert(reader);
        lblStatus.setText(updateCount + " row inserted.");
        this.btnRefresh.doClick();
    }

    public void deleteActionPerformed(ActionEvent e)
    {
        int updateCount = readerDAO.delete(txtReaderID.getText());
        lblStatus.setText(updateCount + " row deleted.");
        this.btnRefresh.doClick();
    }

    public void findActionPerformed(ActionEvent e)
    {
        Reader readerVO = readerDAO.findByPrimaryKey(txtReaderID.getText());
        txtName.setText(readerVO.getName());
        txtReaderID.setText(readerVO.getReaderId());
        txtBirthday.setText(readerVO.getBirthday().toString());
        btnYes.setSelected(readerVO.getMarried());
        txtMaxAllowed.setText(String.valueOf(readerVO.getMaxAllowed()));
        txtEmail.setText(readerVO.getEmail());
        this.btnRefresh.doClick();
    }

    public void updateActionPerformed(ActionEvent e)
    {
        Reader readerVO = new Reader();
        readerVO.setName(txtName.getText());
        readerVO.setReaderId(txtReaderID.getText());
        readerVO.setBirthday(java.sql.Date.valueOf(txtBirthday.getText()));
        readerVO.setMarried(btnYes.isSelected());
        readerVO.setMaxAllowed(Integer.parseInt(txtMaxAllowed.getText()));
        readerVO.setEmail(txtEmail.getText());
        int updateCount = readerDAO.update(readerVO);
        lblStatus.setText(updateCount + " row updated.");
        this.btnRefresh.doClick();
    }

    public void refreshActionPerformed(ActionEvent e)
    {
        try
        {
            Collection<Reader> readers = readerDAO.findAll();
            tblReaders.refreshDataObject(readers, null);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        lblStatus.setText("Datagrid refreshed.");
    }

    class ReaderInsertListener implements ActionListener
    {
        private ReaderManager frame;

        public ReaderInsertListener(ReaderManager frame)
        {
            this.frame = frame;
        }

        public void actionPerformed(ActionEvent e)
        {
            frame.insertActionPerformed(e);
        }
    }

    class ReaderDeleteListener implements ActionListener
    {
        private ReaderManager frame;

        public ReaderDeleteListener(ReaderManager frame)
        {
            this.frame = frame;
        }

        public void actionPerformed(ActionEvent e)
        {
            frame.deleteActionPerformed(e);
        }
    }

    class ReaderFindListener implements ActionListener
    {
        private ReaderManager frame;

        public ReaderFindListener(ReaderManager frame)
        {
            this.frame = frame;
        }

        public void actionPerformed(ActionEvent e)
        {
            frame.findActionPerformed(e);
        }
    }

    class ReaderUpdateListener implements ActionListener
    {
        private ReaderManager frame;

        public ReaderUpdateListener(ReaderManager frame)
        {
            this.frame = frame;
        }

        public void actionPerformed(ActionEvent e)
        {
            frame.updateActionPerformed(e);
        }
    }

    class ReaderRefreshListener implements ActionListener
    {
        private ReaderManager frame;

        public ReaderRefreshListener(ReaderManager frame)
        {
            this.frame = frame;
        }

        public void actionPerformed(ActionEvent e)
        {
            frame.refreshActionPerformed(e);
        }
    }

    public static void main(String[] args)
    {
        new ReaderManager();
    }
}
