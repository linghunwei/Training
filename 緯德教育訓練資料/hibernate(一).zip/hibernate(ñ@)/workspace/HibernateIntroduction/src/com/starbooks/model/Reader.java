package com.starbooks.model;

import java.sql.*;

public class Reader
{
    private String name, readerId, email;
    private Date birthday;
    private boolean married;
    private int maxAllowed;

    public Date getBirthday()
    {
        return birthday;
    }

    public void setBirthday(Date birthday)
    {
        this.birthday = birthday;
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public boolean getMarried()
    {
        return married;
    }

    public void setMarried(boolean married)
    {
        this.married = married;
    }

    public int getMaxAllowed()
    {
        return maxAllowed;
    }

    public void setMaxAllowed(int maxAllowed)
    {
        this.maxAllowed = maxAllowed;
    }

    public String getReaderId()
    {
        return readerId;
    }

    public void setReaderId(String readerId)
    {
        this.readerId = readerId;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }
}
